import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import org.json.JSONArray;
import org.json.JSONObject;

public class Weather_Forecast implements ActionListener {
	
	
	private static String[] optionsToChoose = {
			"Ang Mo Kio", 
			"Bedok",
			"Bishan",
			"Boon Lay",
			"Bukit Batok",
			"Bukit Merah",
			"Bukit Panjang",
			"Bukit Timah",
			"Central Water Catchment",
			"Changi",
			"Choa Chu Kang",
			"Clementi",
			"City",
			"Geylang",
			"Hougang",
			"Jalan Bahar",
			"Jurong East",
			"Jurong Island",
			"Jurong West",
			"Kallang",
			"Lim Chu Kang",
			"Mandai",
			"Marine Parade",
			"Novena",
			"Pasir Ris",
			"Paya Lebar",
			"Pioneer",
			"Pulau Tekong",
			"Pulau Ubin",
			"Punggol",
			"Queenstown",
			"Seletar",
			"Sembawang",
			"Sengkang",
			"Sentosa",
			"Serangoon",
			"Southern Islands",
			"Sungei Kadut",
			"Tampines",
			"Tanglin",
			"Tengah",
			"Toa Payoh",
			"Tuas",
			"Western Islands",
			"Western Water Catchment",
			"Woodlands",
			"Yishun"};
	
	private static JComboBox<String> jComboBox;
	
	private static JLabel optionsLabel;
	private static JButton button;
	private static JLabel output;
	
	public static void main(String[] args) {
		
		JPanel panel = new JPanel();
		JFrame frame = new JFrame();
		frame.setSize(480, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(panel);
		
		panel.setLayout(null);
		
		optionsLabel = new JLabel("Choose Location");
		optionsLabel.setBounds(10, 20, 120, 25);
        panel.add(optionsLabel);
		
		jComboBox = new JComboBox<>(optionsToChoose);
        jComboBox.setBounds(120, 20, 180, 25);
        panel.add(jComboBox);
		
		button = new JButton("Check");
		button.setBounds(300, 20, 80, 25);
		button.addActionListener(new Weather_Forecast());
		panel.add(button);
		
		output = new JLabel("");
		output.setBounds(10, 50, 500, 25);
		panel.add(output);
		
		frame.setVisible(true);
		
	}

	@Override
	public void actionPerformed(ActionEvent e){
		// TODO Auto-generated method stub
		String input = jComboBox.getItemAt(jComboBox.getSelectedIndex());
        
        try {
        URL url = new URL("https://api.data.gov.sg/v1/environment/2-hour-weather-forecast");
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		con.setRequestMethod("GET");
		con.connect();
		
		StringBuilder informationString = new StringBuilder();
        Scanner scanner = new Scanner(url.openStream());

        while (scanner.hasNext()) {
            informationString.append(scanner.nextLine());
        }
        //Close the scanner
        scanner.close();

        String singleString = informationString.toString();
        
        JSONObject obj1 = new JSONObject(singleString);
        JSONArray arr1 = obj1.getJSONArray("items");
        JSONObject obj2 = arr1.getJSONObject(0);
        JSONArray arr2 = obj2.getJSONArray("forecasts");
        
        for (int i = 0; i < arr2.length(); i++) {
            JSONObject obj3 = arr2.getJSONObject(i);
            String obj4 = obj3.getString("area");
            
            if (obj4.equals(input)) {
            	String obj5 = obj3.getString("forecast");
//            	System.out.println(obj4 + ", " + obj5);
            	output.setText("The weather for " + obj4 + " is: " + obj5);
            }
        }
		
        } catch (Exception error) {
            System.out.println("Something went wrong.");
        }
		

		}
		
	}


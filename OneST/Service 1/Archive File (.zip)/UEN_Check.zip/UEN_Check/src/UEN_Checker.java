import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class UEN_Checker implements ActionListener {
	
	
	private static String[] optionsToChoose = {"Businesses registered with ACRA",
											   "Local companies registered with ACRA",
											   "Other entities"};
	private static JComboBox<String> jComboBox;
	
	private static JLabel optionsLabel;
	private static JLabel inputLabel;
	private static JTextField inputText;
	private static JButton button;
	private static JLabel output;
	
	public static void main(String[] args) {
		
		
		JPanel panel = new JPanel();
		JFrame frame = new JFrame();
		frame.setSize(400, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(panel);
		
		panel.setLayout(null);
		
		optionsLabel = new JLabel("UEN Format");
		optionsLabel.setBounds(10, 20, 80, 25);
        panel.add(optionsLabel);
		
		jComboBox = new JComboBox<>(optionsToChoose);
        jComboBox.setBounds(100, 20, 265, 25);
        panel.add(jComboBox);
		
		inputLabel = new JLabel("Input UEN");
		inputLabel.setBounds(10, 50, 80, 25);
		panel.add(inputLabel);
		
		inputText = new JTextField(20);
		inputText.setBounds(100, 50, 165, 25);
		panel.add(inputText);
		
		button = new JButton("Verify");
		button.setBounds(0, 80, 80, 25);
		button.addActionListener(new UEN_Checker());
		panel.add(button);
		
		output = new JLabel("");
		output.setBounds(100, 80, 300, 25);
		panel.add(output);
		
		frame.setVisible(true);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String input = inputText.getText();
		String type = jComboBox.getItemAt(jComboBox.getSelectedIndex());
		
		String regex1 = "\\d{8}[A-Z]";
		String regex2 = "2\\d{8}[A-Z]";
		String regex3 = "[ST]\\d{2}(LP|LL|FC|PF|RF|MQ|MM|NB|CC|CS|MB|FM|GS|DP|CP|NR|CM|CD|MD|HS|VH|CH|MH|CL|XL|CX|HC|RP|TU|TC|FB|FN|PA|PB|SS|MC|SM|GA|GB)\\d{4}[A-Z]";

		if (input.equals("")) {
			output.setText("Please input a value.");
		}
		
		else if (type.equals("Businesses registered with ACRA")) {
			
			Pattern p = Pattern.compile(regex1);
			Matcher m = p.matcher(input);
			
			if (m.matches() == true) {
				output.setText("The UEN comply with the correct format.");
			}
			
			else {
				output.setText("The UEN is in the wrong format.");
			}
		}
		
		else if (type.equals("Local companies registered with ACRA")) {
//			System.out.println(type);
			
			Pattern p = Pattern.compile(regex2);
			Matcher m = p.matcher(input);
			
			if (m.matches() == true) {
				output.setText("The UEN comply with the correct format.");
			}
			
			else {
				output.setText("The UEN is in the wrong format.");
			}
		}
		
		else {
//			System.out.println(type);
			
			Pattern p = Pattern.compile(regex3);
			Matcher m = p.matcher(input);
			
			if (m.matches() == true) {
				output.setText("The UEN comply with the correct format.");
			}
			
			else {
				output.setText("The UEN is in the wrong format.");
			}
		}
		
	}
}
